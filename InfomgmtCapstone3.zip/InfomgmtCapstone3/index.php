<!DOCTYPE html>

<?php
//Step1
 $db = mysqli_connect('127.0.0.1','root','root','WearableData')
 or die('Error connecting to MySQL server.');
?>

<html>
<head><link href="css/projectStyle.css" type = "text/css" rel="stylesheet">
<link rel="stylesheet/less" type="text/css" href="css/sleepGraph.css" />
<script src="https://cdn.jsdelivr.net/npm/less@4.1.1" ></script>
<title>Dashboard</title>
</head>

<body>
	<header>
    <img src="images/siteName.png" width="450" height="100"/>



	</header>
	<nav>
		<a href="index.php">Dashboard</a>
  		<a href="profile.php">Profile</a>
 	 	<a href="#diet.php">Diet</a>
    <a href="active.php">Activity Summary</a>
	</nav>
	<br>


   <! --- Personalised Hello (General table)--- >

  		<h2 class ="welcome">
  			<?php
  				$query = "SELECT * FROM GeneralData WHERE id = 'p01'";
  				mysqli_query($db, $query) or die('Error querying database.');
  				$result = mysqli_query($db, $query);
  				$row = mysqli_fetch_array($result);


  	 			echo 'Hello, ' . $row['firstName'] . ' ';
  	 		?>
  		</h2>

  		<h3>Here are this week's summaries!</h3>

   <! --- Maximum Heart Rate (General table) --- >

  	<section class = "heartbeat">
  	<br>
  	<br>
  	<h3>Max Heart Rate</h3>
  	<div class="human-heart">
  		<div class="container"><img src="images/heart2.png" class="human-heart" alt="human heart" width="100" height="100"/>
  		</div>
  		<div class="top"> 	<?php
  				$query = "SELECT * FROM GeneralData WHERE id = 'p01'";
  				mysqli_query($db, $query) or die('Error querying database.');
  				$result = mysqli_query($db, $query);
  				$row = mysqli_fetch_array($result);


  	 			echo $row['maxHeartRate'] . ' '; ?>
  		</div>

  		</div>


   <! --- Steps --- >

  	</section>
    	<br>
    			<section class = "step">
    			<br>
    			<h3>
      		<?php
          		$query = "SELECT * FROM GeneralData WHERE id = 'p01' ";
         			mysqli_query($db, $query) or die('Error querying database.');
          		$result = mysqli_query($db, $query);
          		$row = mysqli_fetch_array($result);


          		echo 'Good Job, ' . $row['firstName'] . '!' . '<br>';
          		echo 'You are .... '. 'away from your goal steps!';
      		?>
    			</h3>
    			<div class="steps"><img src="images/robot.png" width="160" height="150"/></div>

    	</section>

   <! --- Sleep Duration Graph (Wellness table)--- >



  			<h4><b>Hours of Sleep</b></h4>
  				<?php

  			$query = "SELECT * FROM WellnessPerson1 LIMIT 16,8";
  			mysqli_query($db, $query) or die('Error querying database.');


  			$result = mysqli_query($db, $query);
  			$row = mysqli_fetch_array($result);
  			$days = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
  			$counter = 0;

  			while ($row = mysqli_fetch_array($result)) {
   				echo '<section class="bar-graph bar-graph-vertical bar-graph-two">
    						<div class="bar-one bar-container">
      					<div class="bar" data-percentage ="' .$row['sleep_duration_h'] . '"' . 'style="--bar-value:'.$row['sleep_duration_h']*10 .'%;"></div>
      					<span class="year">' . $days[$counter] . '</span></div>';
    				$counter = $counter + 1;

  					}
  				?>



  <br>
  <footer> &copy; Team 3: Miji / Sumedha / Caitlin</footer>

  </body>


  </html>
