<!DOCTYPE html>

<?php
//Step1
 $db = mysqli_connect('127.0.0.1','root','root','WearableData')
 or die('Error connecting to MySQL server.');
?>

<html>
<head><link href="css/projectStyle.css" type = "text/css" rel="stylesheet">
<link rel="stylesheet/less" type="text/css" href="css/sleepGraph.css" />
<script src="https://cdn.jsdelivr.net/npm/less@4.1.1" ></script>
<title>Dashboard</title>
</head>

<body>
	<header>
    <img src="images/siteName.png" width="450" height="100"/>



	</header>
	<nav>
		<a href="index.php">Dashboard</a>
  		<a href="profile.php">Profile</a>
 	 	<a href="#diet.php">Diet</a>
    <a href="active.php">Activity Summary</a>
	</nav>
	<br>
	<br>


 <! --- Profile Details (General table)--- >

	<img src="images/profile.png" width="150" height="150" class= "profilepic"/>
	<aside class = "profile">
	<h2>
			<?php
				$query = "SELECT * FROM GeneralData WHERE id = 'p01'";
				mysqli_query($db, $query) or die('Error querying database.');
				$result = mysqli_query($db, $query);
				$row = mysqli_fetch_array($result);


	 			echo $row['firstName'] . ' ' . $row['surname'];
	 		?>
		</h2>
		<p>
		<?php
				echo  '<p> <b class = "greenTitle">Age: </b>' . $row['age'] . '</p> ';
				echo  '<p> <b class = "greenTitle">Gender: </b>' . $row['gender'] . '</p> ';
				echo  '<p> <b class = "greenTitle">Height: </b>' . $row['height'] . 'cm</p> ';


		?>
		</p>
	</aside>

</body>



</html>
