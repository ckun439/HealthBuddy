<!DOCTYPE html>

<?php
//Step1
 $db = mysqli_connect('127.0.0.1','root','root','WearableData')
 or die('Error connecting to MySQL server.');
?>

<html>
<head><link href="css/projectStyle.css" type = "text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/activeMinute.css" />
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<title>Dashboard</title>
</head>

<body>
	<header>
    <img src="images/siteName.png" width="450" height="100"/>



	</header>
	<nav>
		<a href="index.php">Dashboard</a>
  		<a href="profile.php">Profile</a>
 	 	<a href="diet.php">Diet</a>
    <a href="active.php">Activity Summary</a>
	</nav>
	<br>
	<br>

</body>


   <! --- active minutes DAILY widgets--- >
   <!--Widget showing LIGHT activity time-->


<body id="firstPage">
  <?php
    $sql = 'SELECT lightActive FROM ActivePerson1 ORDER BY ID DESC LIMIT 7';
    //make the query and get the result
    $result = mysqli_query($db, $sql);
    //get the row as an array
    $lightActivity = mysqli_fetch_all($result, MYSQLI_ASSOC);
    //itterate through array stored in the array
    foreach ($lightActivity as $key => $value){
      foreach ($value as $k => $v){
        //add it to the light activity sum
        $lightPrint += $v;
      }
    }
  ?>
   <div class="card-body">
     <div class = "float-right">
       <img src="images/jumpingman.png" width="80" height="80">
     </div>
     <div class= "float-left"
     <h3>
       <span class="activitytime">Light:</span>
       <!--change the bellow number to get a link from our database-->
      <span class="count"><?php echo $lightPrint; ?></span>
     </h3>
     <p>week active minutes<p>
     </div>
   </div>
   <!--finish Widget showing LIGHT activity time-->
   <!--Widget showing MEDIUM activity time-->
   <?php
     $sql = 'SELECT moderateActive FROM ActivePerson1 ORDER BY ID DESC LIMIT 7';
     //make the query and get the result
     $result = mysqli_query($db, $sql);
     //get the row as an array
     $moderateActivity = mysqli_fetch_all($result, MYSQLI_ASSOC);
     //itterate through array stored in the array
     foreach ($moderateActivity as $key => $value){
       foreach ($value as $k => $v){
         //add it to the light activity sum
         $moderatePrint += $v;
       }
     }
   ?>
   <div class="card-body2">
     <div class = "float-right">
       <img src="images/jumpingman.png" width="80" height="80">
     </div>
     <div class= "float-left"
     <h3>
       <span class="activitytime">Middle:</span>
       <!--change the bellow number to get a link from our database-->
      <span class="count"><?php echo $moderatePrint; ?></span>
     </h3>
     <p>week active minutes<p>
     </div>
   </div>
   <!--finish Widget showing MEDIUM activity time-->
   <!--Widget showing HEAVY activity time-->
   <?php
     $sql = 'SELECT veryActive FROM ActivePerson1 ORDER BY ID DESC LIMIT 7';
     //make the query and get the result
     $result = mysqli_query($db, $sql);
     //get the row as an array
     $veryActive = mysqli_fetch_all($result, MYSQLI_ASSOC);
     //itterate through array stored in the array
     foreach ($veryActive as $key => $value){
       foreach ($value as $k => $v){
         //add it to the light activity sum
         $veryPrint += $v;
       }
     }
   ?>
   <div class="card-body3">
     <div class = "float-right">
       <img src="images/jumpingman.png" width="80" height="80">
     </div>
     <div class= "float-left"
     <h3>
       <span class="activitytime">Heavy:</span>
       <!--change the bellow number to get a link from our database-->
      <span class="count"><?php echo $veryPrint; ?></span>
     </h3>
     <p>week active minutes<p>
     </div>
   </div>
   <!--finish Widget showing HEAVY activity time-->
   <!--add the java thingy to animate it to do the number counting-->
   <script type="text/javascript">
   $('.count').each(function(){
     $(this).prop('Counter',0).animate({
       Counter: $(this).text()
     }, {
       duration:4000,
       easing:'swing',
       step: function(now){
         $(this).text(Math.ceil(now));
       }
     });
   });
   </script>


 </body>




</html>
