<!DOCTYPE html>

<?php
//Step1
 $db = mysqli_connect('127.0.0.1','root','root','WearableData')
 or die('Error connecting to MySQL server.');
?>

<html>
<head><link href="css/projectStyle.css" type = "text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/activeMinute.css" />
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<title>Dashboard</title>
</head>

<body>
	<header>
    <img src="images/siteName.png" width="450" height="100"/>



	</header>
	<nav>
		<a href="index.php">Dashboard</a>
  		<a href="profile.php">Profile</a>
 	 	<a href="#diet.php">Diet</a>
    <a href="active.php">Activity Summary</a>
	</nav>
	<br>
	<br>

</body>
   <! --- active minutes DAILY widgets--- >
   <!--Widget showing LIGHT activity time-->

<body id="firstPage">
   <div class="card-body">
     <div class = "float-right">
       <img src="images/jumpingman.png" width="80" height="80">
     </div>
     <div class= "float-left"
     <h3>
       <span class="activitytime">Light:</span>
       <!--change the bellow number to get a link from our database-->
       <?php
           $query = "SELECT * FROM ActivePerson1";
           mysqli_query($db, $query) or die('Error querying database.');
           $result = mysqli_query($db, $query);
           $row = mysqli_fetch_array($result);
           $lightActivePrint = $row['lightActive'];
          ?>
      <span class="count"><?php echo $lightActivePrint; ?></span>
     </h3>
     <p>active minutes today<p>
     </div>
   </div>
   <!--finish Widget showing LIGHT activity time-->
   <!--Widget showing MEDIUM activity time-->
   <div class="card-body2">
     <div class = "float-right">
       <img src="images/jumpingman.png" width="80" height="80">
     </div>
     <div class= "float-left"
     <h3>
       <span class="activitytime">Medium:</span>
       <!--change the bellow number to get a link from our database-->
       <?php
           $query = "SELECT * FROM ActivePerson1";
           mysqli_query($db, $query) or die('Error querying database.');
           $result = mysqli_query($db, $query);
           $row = mysqli_fetch_array($result);
           $moderateActivePrint = $row['moderateActive'];
          ?>
      <span class="count"><?php echo $moderateActivePrint; ?></span>
     </h3>
     <p>active minutes today<p>
     </div>
   </div>
   <!--finish Widget showing MEDIUM activity time-->
   <!--Widget showing HEAVY activity time-->
   <div class="card-body3">
     <div class = "float-right">
       <img src="images/jumpingman.png" width="80" height="80">
     </div>
     <div class= "float-left"
     <h3>
       <span class="activitytime">Heavy:</span>
       <!--change the bellow number to get a link from our database-->
       <?php
           $query = "SELECT * FROM ActivePerson1";
           mysqli_query($db, $query) or die('Error querying database.');
           $result = mysqli_query($db, $query);
           $row = mysqli_fetch_array($result);
           $veryActivePrint = $row['veryActive'];
          ?>
      <span class="count"><?php echo $veryActivePrint; ?></span>
     </h3>
     <p>active minutes today<p>
     </div>
   </div>
   <!--finish Widget showing HEAVY activity time-->
   <!--add the java thingy to animate it to do the number counting-->
   <script type="text/javascript">
   $('.count').each(function(){
     $(this).prop('Counter',0).animate({
       Counter: $(this).text()
     }, {
       duration:4000,
       easing:'swing',
       step: function(now){
         $(this).text(Math.ceil(now));
       }
     });
   });
   </script>



 </body>







</html>
